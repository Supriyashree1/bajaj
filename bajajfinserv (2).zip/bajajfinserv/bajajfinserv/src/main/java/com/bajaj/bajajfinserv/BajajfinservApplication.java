package com.bajaj.bajajfinserv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BajajfinservApplication {

	public static void main(String[] args) {
		SpringApplication.run(BajajfinservApplication.class, args);
	}

}
